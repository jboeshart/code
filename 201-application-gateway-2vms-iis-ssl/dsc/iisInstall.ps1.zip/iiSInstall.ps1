Configuration InstallIIS
{

Param ( [string] $nodeName, $vmNumber )

Import-DscResource -ModuleName PSDesiredStateConfiguration

Node $nodeName
  {
    WindowsFeature WebServerRole
    {
      Name = "Web-Server"
      Ensure = "Present"
    }
    WindowsFeature WebManagementConsole
    {
      Name = "Web-Mgmt-Console"
      Ensure = "Present"
    }
    WindowsFeature WebManagementService
    {
      Name = "Web-Mgmt-Service"
      Ensure = "Present"
    }
    WindowsFeature ASPNet45
    {
      Name = "Web-Asp-Net45"
      Ensure = "Present"
    }
    WindowsFeature HTTPRedirection
    {
      Name = "Web-Http-Redirect"
      Ensure = "Present"
    }
    WindowsFeature CustomLogging
    {
      Name = "Web-Custom-Logging"
      Ensure = "Present"
    }
    WindowsFeature LogginTools
    {
      Name = "Web-Log-Libraries"
      Ensure = "Present"
    }
    WindowsFeature RequestMonitor
    {
      Name = "Web-Request-Monitor"
      Ensure = "Present"
    }
    WindowsFeature Tracing
    {
      Name = "Web-Http-Tracing"
      Ensure = "Present"
    }
    WindowsFeature BasicAuthentication
    {
      Name = "Web-Basic-Auth"
      Ensure = "Present"
    }
    WindowsFeature WindowsAuthentication
    {
      Name = "Web-Windows-Auth"
      Ensure = "Present"
    }
    WindowsFeature ApplicationInitialization
    {
      Name = "Web-AppInit"
      Ensure = "Present"
    }
    Script DownloadUrlRewrite
    {
        TestScript = {
            Test-Path "C:\rewrite_2.0_rtw_x64.msi"
        }
        SetScript ={
            $source = "http://download.microsoft.com/download/6/7/D/67D80164-7DD0-48AF-86E3-DE7A182D6815/rewrite_2.0_rtw_x64.msi"
            $dest = "C:\rewrite_2.0_rtw_x64.msi"
            Invoke-WebRequest $source -OutFile $dest
        }
        GetScript = {@{Result = "DownloadUrlRewrite"}}
        DependsOn = "[WindowsFeature]WebServerRole"
    }
    Package UrlRewrite
    {
        Ensure = "Present"
        Name = "IIS URL Rewrite Module 2"
        Path = "C:\rewrite_2.0_rtw_x64.msi"
        Arguments = "/quiet"
        ProductId = "EB675D0A-2C95-405B-BEE8-B42A65D23E11"
        DependsOn = "[Script]DownloadUrlRewrite"
    }
    Script DownloadWebDotConfig
    {
        TestScript = {
            Test-Path "C:\inetpub\wwwroot\web.config"
        }
        SetScript ={
            $source = "https://raw.githubusercontent.com/jboeshart/code/master/201-application-gateway-2vms-iis-ssl/artifacts/web.config"
            $dest = "C:\inetpub\wwwroot\web.config"
            Invoke-WebRequest $source -OutFile $dest
        }
        GetScript = {@{Result = "DownloadWebDotConfig"}}
        DependsOn = "[WindowsFeature]WebServerRole"
    }
    Script DownloadDefaultDotHtm
    {
        TestScript = {
            Test-Path "C:\inetpub\wwwroot\default.htm"
        }
        SetScript ={
            $vmNum = $using:vmNumber
            $source = "https://raw.githubusercontent.com/jboeshart/code/master/201-application-gateway-2vms-iis-ssl/artifacts/$vmNum.default.htm"
            $dest = "C:\inetpub\wwwroot\default.htm"
            Invoke-WebRequest $source -OutFile $dest
        }
        GetScript = {@{Result = "DownloadDefaultDotHtm"}}
        DependsOn = "[WindowsFeature]WebServerRole"
    }
  }
}